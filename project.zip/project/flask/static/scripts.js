function sampleFunction() {
  location.reload();
}
